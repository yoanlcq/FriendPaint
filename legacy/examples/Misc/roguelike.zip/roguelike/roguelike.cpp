#include <cstdlib>
#include <iostream>
#include <cmath>
#include <SFML/Graphics.hpp>

#include "guy.hpp"

int main(int argc, char *argv[]) {

  sf::RenderWindow window;

  //La taille du côté d'un bouton
  const unsigned BUTTON_SIDE = 3*14;
  //Largeur et hauteur de la taille de la fenetre (seront réutilisées)
  unsigned win_w = BUTTON_SIDE*3, win_h = BUTTON_SIDE*4;

  window.setVerticalSyncEnabled(true); //Optionnel
  window.create(sf::VideoMode(win_w, win_h), "Le rogue-like de Charles");

  //On fait vivre le bonhomme et son monde.
  Guy::live(sf::Vector2f(win_w/2, (win_h-BUTTON_SIDE)/2), sf::IntRect(0, 0, win_w, win_h-BUTTON_SIDE));

  //La direction vers laquelle le bonhomme évolue à tout moment.
  unsigned current_direction = NONE;
  //Les directions valides sont définies dans 'guy.hpp': 
  // enum directions {LEFT = 0, NONE = 1, RIGHT = 2}; 

  //Boucle principale
  while(window.isOpen()) {
    
    window.clear();

    //On dit au bonhomme de continuer à s'animer dans la direction courante, puis on le dessine.
    Guy::tell(current_direction);
    Guy::draw(window);

    window.display();

    sf::Event event;
    //On traite chaque évènement tant qu'il y en a.
    while(window.pollEvent(event)) {
      switch(event.type) {


	/*
	  Lorsque le bouton gauche de la souris est pressé
	  (pas forcément relâché) et que c'est sur un de vos boutons,
	  vous devez simplement assigner à 'current_direction' la valeur de la direction.
	  
	  Pour vérifier si la souris se situe dans votre bouton,
	  vous pouvez faire des calculs d'après leurs positions et tailles, mais c'est crade.
	  Meilleur moyen :
	  Les sf::FloatRect et sf::IntRect ont une méthode 'contains()' qui peuvent dire si un point est contenu dedans.
	  Et pour obtenir un sf::FloatRect à partir de votre sf::RectangleShape, utilisez sa méthode 'getGlobalBounds()';
	  RTFM !
	*/


      case sf::Event::Closed:
	window.close();
	break;
      case sf::Event::Resized:
	win_w = event.size.width;
	win_h = event.size.height;
	window.setView(sf::View(sf::FloatRect(0, 0, win_w, win_h)));
	break;
      case sf::Event::KeyPressed:
	switch(event.key.code) {
	case sf::Keyboard::Left:  current_direction = LEFT; /* 0 */ break;
	case sf::Keyboard::Right: current_direction = RIGHT; /* 2 */ break;
	}
	break;
      case sf::Event::KeyReleased:
	switch(event.key.code) {
	case sf::Keyboard::Left:  if(current_direction==LEFT)  current_direction = NONE; /* 1 */ break;
	case sf::Keyboard::Right: if(current_direction==RIGHT) current_direction = NONE; /* 1 */ break;
	}
	break;
      } //Fin switch
    } //Fin évènements
  } //Fin boucle principale
  exit(EXIT_SUCCESS);
}
