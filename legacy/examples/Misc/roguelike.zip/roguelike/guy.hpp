#ifndef GUY_HPP
#define GUY_HPP

#include <SFML/Graphics.hpp>

enum directions {LEFT = 0, NONE = 1, RIGHT = 2};

class Guy {
private:
  Guy() {};
  static sf::Texture guy_tex, bg_tex;
  static sf::Sprite guy_spr, bg_spr;
  static unsigned frameno, spriteno, old_direction;
  static bool step, moving;
  static sf::IntRect bg_rect;
public:
  static void live(sf::Vector2f guy_center, sf::IntRect bg_rect_);
  static void tell(unsigned direction);
  static void draw(sf::RenderWindow &window);
};

#endif //GUY_HPP
