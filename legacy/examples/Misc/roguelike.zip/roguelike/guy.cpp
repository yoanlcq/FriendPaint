#include <cstdlib>
#include <iostream>
#include <SFML/Graphics.hpp>

#include "guy.hpp"


void Guy::live(sf::Vector2f guy_center, sf::IntRect bg_rect_) {
  guy_tex.loadFromFile("guy_tex.png");
  guy_tex.setRepeated(false);
  guy_spr.setTexture(guy_tex);
  guy_spr.setTextureRect(sf::IntRect(0, 0, 14, 21));
  guy_spr.setOrigin(14/2, 21/2);
  guy_spr.setPosition(guy_center);

  bg_rect = bg_rect_;
    
  bg_tex.loadFromFile("bg_tex.png");
  bg_tex.setRepeated(true);
  bg_spr.setTexture(bg_tex);
  bg_spr.setPosition(bg_rect.left - 14, bg_rect.top);
  bg_rect.width  += 14*2;
  bg_spr.setTextureRect(bg_rect);

  frameno=0;
  old_direction = RIGHT;
  step = false;
  moving = false;
}
void Guy::tell(unsigned direction) {
  if(direction==NONE) {
    spriteno = (old_direction==LEFT ? 6 : 1);
    guy_spr.setTextureRect(sf::IntRect((spriteno-1)*14, 0, 14, 21));
    return;
  }
  frameno++;
  old_direction = direction;
  bg_spr.move((direction==LEFT ? 1 : -1), 0);
  
  if(frameno == 14*1/3) {
    step = !step;
    spriteno = (direction==LEFT ? (step ? 4 : 5) : (step ? 2 : 3));
    guy_spr.setTextureRect(sf::IntRect((spriteno-1)*14, 0, 14, 21));
  }
  if(frameno == 14*2/3) { 
    spriteno = (direction==LEFT ? 6 : 1);
    guy_spr.setTextureRect(sf::IntRect((spriteno-1)*14, 0, 14, 21));
  }
  if(frameno >= 14) {
    bg_spr.setPosition(bg_rect.left - 14, bg_rect.top);
    frameno = 0;
  }
}
void Guy::draw(sf::RenderWindow &window) {
  window.draw(bg_spr);
  window.draw(guy_spr);
}

sf::Texture Guy::guy_tex, Guy::bg_tex;
sf::Sprite Guy::guy_spr, Guy::bg_spr;
unsigned Guy::frameno, Guy::spriteno, Guy::old_direction;
sf::IntRect Guy::bg_rect;
bool Guy::step, Guy::moving;

